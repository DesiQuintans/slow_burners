# SR_Slow_Burners changelog

## v1.0.1 (2024-01-10)

- Forgot to update the package description.

## v1.0.0 (2024-01-10)

- Initial release.
