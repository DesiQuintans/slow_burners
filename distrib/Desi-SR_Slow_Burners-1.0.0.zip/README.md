# SR_Slow_Burners 1.0.0

The Slow Burners is a [SupplyRaid](https://h3vr.thunderstore.io/package/Packer/SupplyRaid/) faction designed to work well with characters that focus on scavenging and improvisational play. Over 5 rounds, the Slow Burners go from a civilian force armed with pistols and not much else, up to a well-equipped and armoured militia prepared to defend themselves against you.



# Play tips

- Roaming squads respawn infinitely, but their respawn timers are quite long.
  
- Shield-carrying guards are fatal in cramped indoor supply points. 



# Known issues

- I don't have snipers enabled because it seems to make SupplyRaid end the levels early (like I kill 3 squad sosigs somewhere and the level is completed).



# Future wishlist

- When SupplyRaid supports custom sosigs, I will make the appearance of the Slow Burners more consistent. Currently, I have had to use different kinds of built-in sosigs to balance their armour and weaponry across stages.
