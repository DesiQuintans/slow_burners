# SR_Slow_Burners 1.1.0

The Slow Burners is a [SupplyRaid](https://h3vr.thunderstore.io/package/Packer/SupplyRaid/) faction that works well with slow-starting characters who focus on scavenging and improvisational play. Over 5 rounds, they progress from pistol-wielding civilians to a well-equipped and armoured force prepared to defend themselves.



# Play tips

- Roaming squads respawn infinitely, but their respawn timers are quite long.
- Shield-carrying guards are fatal in cramped indoor supply points.
- The most useful kind of sosiggun (an LMG) is held by a rare Heavy Operator guarding some supply points on Level 5 onwards. He'll be a challenge!
  


# Known issues

- I don't have snipers enabled because it seems to make SupplyRaid end the levels early (like I kill 3 squad sosigs somewhere and the level is completed).



# Future wishlist

- When SupplyRaid supports custom sosigs, I will make the appearance of the Slow Burners more consistent. Currently, I have had to use different kinds of built-in sosigs to balance their armour and weaponry across stages.



# Changelog

## v1.1.0 (2024-01-11)

- Removed or reduced the spawning of LMG-wielding sosigs across all levels. LMGs, especially the M60, were just too good to the point where it became more viable to use the LMG than to use your own guns, especially to defeat the stronger body armour of sosigs from Level 4 onwards. It was even worse when the LMGs could be reloaded in Spawnlocked mode.
	- Levels 1 & 2: There are not (and never were) any sosiggun LMGs at these levels.
	- Level 3: Jungle Riflewieners no longer spawn; no LMGs at this level now.
	- Level 4: There are not (and never were) any sosiggun LMGs at this level.
	- Level 5/Endless: You only start enountering LMGs here. A Tier 5 Heavy Operator armed with an LMG can spawn as a supply point guard. There's about a 4% chance of spawning at least one in every level. You'll have to earn the LMG by taking down a very well-armoured enemy.


## v1.0.1 (2024-01-10)

- Forgot to update the package description.


## v1.0.0 (2024-01-10)

- Initial release.
